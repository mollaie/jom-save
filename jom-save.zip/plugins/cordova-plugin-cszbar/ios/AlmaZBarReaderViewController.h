//
//  AlmaZBarReaderViewController.h
//  BarCodeMix
//
//  Created by eCompliance on 23/01/15.
//
//

#import "ZBarReaderViewController.h"

@interface AlmaZBarReaderViewController : ZBarReaderViewController

@end
